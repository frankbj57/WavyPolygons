#include <stdio.h>

void writeDoubleWithText(char *, double);

int main()
{
	int x;
	double Resultat = 42; // Lang beregning

	x = writeDoubleWithText("Resultat", Resultat);
	// Forkert!!!

	return 0;
}

void writeDoubleWithText(char * text, double value)
{
	printf("%s: %f\n", text, value);
	return 0;
}
