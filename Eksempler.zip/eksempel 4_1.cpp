#include <stdio.h>
#define _USE_MATH_DEFINES
#include <math.h>

double degreeToRadian( double );		//prototype

int main()
{
	double x = 0.0;
	double d0, d360;

	d0 = degreeToRadian(x);				// kald - gem
	d360 = degreeToRadian(360.0);		// kald - gem

	printf("%f degrees are %f rads\n", 
		x, d0);

	printf("90.0 degrees are %f rads\n",
		degreeToRadian(90.0));			// kald - send videre

	degreeToRadian(45.0);				// kald - Returv�rdien smides v�k!

	return 0;
}


double degreeToRadian(double degree)	// implementation
{
	double Resultat = 0;

	Resultat = (degree / 180)*M_PI;

	return Resultat;
}