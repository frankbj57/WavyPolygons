#define _USE_MATH_DEFINES
#include <math.h>
#include "function.h"

double degreeToRadian(double degree)	// implementation
{
	double Resultat = 0;

	Resultat = (degree / 180)*M_PI;

	return Resultat;
}
