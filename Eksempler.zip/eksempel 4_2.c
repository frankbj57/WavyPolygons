#include <stdio.h>

void udskrivMenu( void );						//FUNKTIONS - PROTOTYPE
int indlaesValg(void);

void main()
{
	int svar = 0;

	do
	{
		udskrivMenu();								//FUNKTIONS - KALD

		svar = indlaesValg();

		switch (svar)
		{

		}

	} while (svar != 4);
}

void udskrivMenu( void )						//FUNKTIONS - HEADER
{
	printf( "*** HOVEDMENU ***\n\n" );
	printf( "1. Start nyt spil.\n" );
	printf( "2. Hent gemt spil.\n" );
	printf( "3. Gem spil.\n" );
	printf( "4. Afslut.\n\n" );
}

int indlaesValg(void)
{
	int Result;

	scanf_s("%d", &Result);

	return Result;
}