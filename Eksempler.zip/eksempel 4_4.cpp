const int A = 3; // global konstant
int f(int); // global funktion

int main()
{
	int b = 2; // lokal variabel
	{
		int c; // lokal variabel
		b = A; // OK
		c = f(b); // OK
	}
	b = c; // ERROR !!!
}

int f(int d) // d lokal variabel
{
	int e = d; // lokal variabel
	d = b; // ERROR !!!
	d = A; // OK

	return e * d;
}
