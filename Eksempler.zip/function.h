#pragma once
double degreeToRadian(double);		//prototype
