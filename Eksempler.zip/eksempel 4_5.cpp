#include <stdio.h>
#include <conio.h>

// Global variable
int i;

// Funktion
void printTiere(int tier);

int main()
{
	for (i = 1; i <= 20; i++)
	{
		printTiere(i);
		printf("Tryk paa en tast for at fortsaette\n");
		_getch();
	}
	return 0;
}

void printTiere(int tier)
{
	for (i = 0; i <= 9; i++)
	{
		printf("%d ", tier * 10 + i);
	}

	printf("\n");
}